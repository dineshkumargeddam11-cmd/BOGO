
import React from 'react';

const GALLERY_IMAGES = [
  {
    id: 1,
    src: "https://images.unsplash.com/photo-1606914469725-e39660419185?q=80&w=1000&auto=format&fit=crop",
    alt: "Traditional Spices",
    caption: "Authentic Spices"
  },
  {
    id: 2,
    src: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?q=80&w=1000&auto=format&fit=crop",
    alt: "Mangoes for Pickle",
    caption: "Farm Fresh Mangoes"
  },
  {
    id: 3,
    src: "https://images.unsplash.com/photo-1589647363585-f4a7d3877b10?q=80&w=1000&auto=format&fit=crop",
    alt: "River Godavari",
    caption: "The Godavari Banks"
  },
  {
    id: 4,
    src: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=1000&auto=format&fit=crop",
    alt: "Sweet Preparation",
    caption: "Handmade with Love"
  }
];

const ImageGallery: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-deepgreen-800">Glimpses of Godavari</h2>
          <p className="text-gray-600 mt-2">The essence of our land, captured in every frame.</p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {GALLERY_IMAGES.map((image) => (
            <div key={image.id} className="group relative h-64 overflow-hidden rounded-lg shadow-md cursor-pointer">
              <img 
                src={image.src} 
                alt={image.alt} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6">
                <span className="text-white font-semibold text-lg tracking-wide">{image.caption}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImageGallery;
