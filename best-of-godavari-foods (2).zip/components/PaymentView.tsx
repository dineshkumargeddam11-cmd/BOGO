
import React, { useState } from 'react';
import { CartItem } from '../types';

interface PaymentViewProps {
  orderDetails: {
    items: CartItem[];
    total: number;
  };
  onClose: () => void;
  onConfirmPayment: () => void;
}

type PaymentMethod = 'card' | 'upi' | 'netbanking';

const PaymentView: React.FC<PaymentViewProps> = ({ orderDetails, onClose, onConfirmPayment }) => {
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');

  // Card State
  const [cardholderName, setCardholderName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvc, setCvc] = useState('');

  // UPI State
  const [upiId, setUpiId] = useState('');

  // Net Banking State
  const [selectedBank, setSelectedBank] = useState('');

  // Handlers for Card
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    const formattedValue = (value.match(/.{1,4}/g) || []).join(' ');
    if (formattedValue.length <= 19) {
      setCardNumber(formattedValue);
    }
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 2) {
      value = value.slice(0, 2) + ' / ' + value.slice(2);
    }
     if (value.length <= 7) {
      setExpiryDate(value);
    }
  };

  const handleCvcChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    if (value.length <= 3) {
      setCvc(value);
    }
  };

  // Validation
  const isCardValid = cardholderName.length > 3 && cardNumber.length === 19 && expiryDate.length === 7 && cvc.length === 3;
  const isUpiValid = upiId.includes('@') && upiId.length > 3;
  const isNetBankingValid = selectedBank !== '';

  const isFormValid = () => {
    switch(paymentMethod) {
      case 'card': return isCardValid;
      case 'upi': return isUpiValid;
      case 'netbanking': return isNetBankingValid;
      default: return false;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b bg-stone-50">
          <div>
             <h2 className="text-xl md:text-2xl font-bold text-deepgreen-800 font-serif">Complete Payment</h2>
             <p className="text-sm text-gray-500">Transaction ID: {Math.floor(Math.random() * 100000000)}</p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800 p-2">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
             </svg>
          </button>
        </div>

        <div className="flex flex-col md:flex-row h-full overflow-hidden">
            
            {/* Sidebar - Payment Methods */}
            <div className="w-full md:w-1/3 bg-stone-50 border-r border-gray-200 p-2 md:p-4 space-y-2 overflow-y-auto">
                <button 
                    onClick={() => setPaymentMethod('card')}
                    className={`w-full text-left px-4 py-4 rounded-lg flex items-center transition-all ${paymentMethod === 'card' ? 'bg-white shadow-md border-l-4 border-saffron-500 text-brand-800' : 'hover:bg-white text-gray-600'}`}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                    <span className="font-semibold">Credit / Debit Card</span>
                </button>
                
                <button 
                    onClick={() => setPaymentMethod('upi')}
                    className={`w-full text-left px-4 py-4 rounded-lg flex items-center transition-all ${paymentMethod === 'upi' ? 'bg-white shadow-md border-l-4 border-saffron-500 text-brand-800' : 'hover:bg-white text-gray-600'}`}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                    </svg>
                    <span className="font-semibold">UPI / QR</span>
                </button>

                <button 
                    onClick={() => setPaymentMethod('netbanking')}
                    className={`w-full text-left px-4 py-4 rounded-lg flex items-center transition-all ${paymentMethod === 'netbanking' ? 'bg-white shadow-md border-l-4 border-saffron-500 text-brand-800' : 'hover:bg-white text-gray-600'}`}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                    </svg>
                    <span className="font-semibold">Net Banking</span>
                </button>
            </div>

            {/* Main Content - Forms */}
            <div className="w-full md:w-2/3 p-6 md:p-8 bg-white overflow-y-auto flex flex-col">
                
                {/* Amount Display */}
                <div className="mb-8 p-4 bg-saffron-50 rounded-lg border border-saffron-200 flex justify-between items-center">
                    <span className="text-gray-700 font-medium">Total Payable Amount</span>
                    <span className="text-2xl font-bold text-deepgreen-800">₹{orderDetails.total.toFixed(2)}</span>
                </div>

                <div className="flex-grow">
                    {paymentMethod === 'card' && (
                        <div className="space-y-5 animate-fade-in">
                             <h3 className="text-lg font-bold text-gray-800 border-b pb-2 mb-4">Enter Card Details</h3>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Cardholder Name</label>
                                <input 
                                    type="text" 
                                    value={cardholderName}
                                    onChange={(e) => setCardholderName(e.target.value)}
                                    placeholder="e.g. A. P. J. Abdul Kalam"
                                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-saffron-500 outline-none transition-all"
                                />
                            </div>
                            <div className="relative">
                                <label className="block text-sm font-medium text-gray-700 mb-1">Card Number</label>
                                <input 
                                    type="text" 
                                    value={cardNumber}
                                    onChange={handleCardNumberChange}
                                    placeholder="0000 0000 0000 0000"
                                    className="w-full p-3 pl-10 border border-gray-300 rounded-md focus:ring-2 focus:ring-saffron-500 outline-none transition-all"
                                />
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400 absolute left-3 top-9" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                                </svg>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                                    <input 
                                        type="text" 
                                        value={expiryDate}
                                        onChange={handleExpiryChange}
                                        placeholder="MM / YY"
                                        className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-saffron-500 outline-none transition-all"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">CVV / CVC</label>
                                    <input 
                                        type="password" 
                                        value={cvc}
                                        onChange={handleCvcChange}
                                        placeholder="123"
                                        maxLength={3}
                                        className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-saffron-500 outline-none transition-all"
                                    />
                                </div>
                            </div>
                            <div className="flex gap-2 mt-2">
                                <div className="h-6 w-10 bg-gray-200 rounded"></div>
                                <div className="h-6 w-10 bg-gray-200 rounded"></div>
                                <div className="h-6 w-10 bg-gray-200 rounded"></div>
                            </div>
                        </div>
                    )}

                    {paymentMethod === 'upi' && (
                        <div className="space-y-6 animate-fade-in">
                            <h3 className="text-lg font-bold text-gray-800 border-b pb-2">Pay via UPI</h3>
                            
                            <div className="flex justify-around mb-6">
                                <div className="text-center cursor-pointer hover:opacity-80 transition-opacity" onClick={() => setUpiId('user@gpay')}>
                                    <div className="w-12 h-12 bg-white border rounded-full flex items-center justify-center mx-auto mb-1 shadow-sm">
                                        <span className="font-bold text-blue-500">G</span>
                                    </div>
                                    <span className="text-xs text-gray-600">Google Pay</span>
                                </div>
                                <div className="text-center cursor-pointer hover:opacity-80 transition-opacity" onClick={() => setUpiId('user@ybl')}>
                                    <div className="w-12 h-12 bg-white border rounded-full flex items-center justify-center mx-auto mb-1 shadow-sm">
                                        <span className="font-bold text-purple-600">Pe</span>
                                    </div>
                                    <span className="text-xs text-gray-600">PhonePe</span>
                                </div>
                                <div className="text-center cursor-pointer hover:opacity-80 transition-opacity" onClick={() => setUpiId('user@paytm')}>
                                    <div className="w-12 h-12 bg-white border rounded-full flex items-center justify-center mx-auto mb-1 shadow-sm">
                                        <span className="font-bold text-cyan-500">Pay</span>
                                    </div>
                                    <span className="text-xs text-gray-600">Paytm</span>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">Enter UPI ID / VPA</label>
                                <input 
                                    type="text" 
                                    value={upiId}
                                    onChange={(e) => setUpiId(e.target.value)}
                                    placeholder="username@bankname"
                                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-saffron-500 outline-none transition-all"
                                />
                                <p className="text-xs text-gray-500 mt-2">A collect request will be sent to your UPI app.</p>
                            </div>
                        </div>
                    )}

                    {paymentMethod === 'netbanking' && (
                        <div className="space-y-6 animate-fade-in">
                             <h3 className="text-lg font-bold text-gray-800 border-b pb-2">Select Bank</h3>
                             <div className="grid grid-cols-2 gap-4">
                                {['SBI', 'HDFC Bank', 'ICICI Bank', 'Axis Bank', 'Kotak Bank', 'Punjab National Bank'].map((bank) => (
                                    <label key={bank} className={`border rounded-lg p-4 flex items-center cursor-pointer transition-all ${selectedBank === bank ? 'border-saffron-500 bg-saffron-50 ring-1 ring-saffron-500' : 'hover:bg-gray-50 border-gray-300'}`}>
                                        <input 
                                            type="radio" 
                                            name="bank" 
                                            className="mr-3 text-saffron-600 focus:ring-saffron-500"
                                            onChange={() => setSelectedBank(bank)}
                                            checked={selectedBank === bank}
                                        />
                                        <span className="font-medium text-gray-700">{bank}</span>
                                    </label>
                                ))}
                             </div>
                             
                             <div className="mt-4">
                                 <label className="block text-sm font-medium text-gray-700 mb-2">Other Banks</label>
                                 <select 
                                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-saffron-500 outline-none bg-white"
                                    onChange={(e) => setSelectedBank(e.target.value)}
                                    value={['SBI', 'HDFC Bank', 'ICICI Bank', 'Axis Bank', 'Kotak Bank', 'Punjab National Bank'].includes(selectedBank) ? '' : selectedBank}
                                >
                                     <option value="">Select another bank</option>
                                     <option value="Canara Bank">Canara Bank</option>
                                     <option value="Union Bank">Union Bank</option>
                                     <option value="Bank of Baroda">Bank of Baroda</option>
                                     <option value="IDFC First Bank">IDFC First Bank</option>
                                 </select>
                             </div>
                        </div>
                    )}
                </div>

                {/* Pay Button */}
                <div className="mt-8 pt-4 border-t">
                  <button
                    onClick={onConfirmPayment}
                    disabled={!isFormValid()}
                    className="w-full bg-deepgreen-700 text-white font-bold py-4 rounded-lg hover:bg-deepgreen-800 transition-colors disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg"
                  >
                     <span className="font-serif tracking-wide">PAY ₹{orderDetails.total.toFixed(2)}</span>
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                         <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                     </svg>
                  </button>
                  <div className="text-center mt-4 flex items-center justify-center gap-2 text-gray-400 text-xs">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                      <span>Payments are 100% Secure & Encrypted</span>
                  </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentView;
