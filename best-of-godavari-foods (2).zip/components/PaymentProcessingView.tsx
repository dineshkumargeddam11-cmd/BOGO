
import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';

interface PaymentProcessingViewProps {
  onSuccess: () => void;
}

const STEPS = [
  "Connecting to payment gateway...",
  "Verifying payment details...",
  "Processing transaction...",
  "Finalizing order...",
  "Payment Successful!",
];

const PaymentProcessingView: React.FC<PaymentProcessingViewProps> = ({ onSuccess }) => {
  const [step, setStep] = useState(0);
  const { clearCart } = useCart();

  useEffect(() => {
    const timers = STEPS.map((_, index) => 
      setTimeout(() => {
        setStep(index);
        if (index === STEPS.length - 1) {
          clearCart();
          setTimeout(onSuccess, 1000); // Wait a bit on success message before closing
        }
      }, (index + 1) * 1500)
    );

    return () => {
      timers.forEach(clearTimeout);
    };
  }, [onSuccess, clearCart]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-8 text-center">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-saffron-600 mx-auto"></div>
        <h2 className="text-2xl font-bold text-deepgreen-800 mt-6">Processing Payment</h2>
        <p className="text-gray-600 mt-2 min-h-[24px] transition-opacity duration-300">
          {STEPS[step]}
        </p>
      </div>
    </div>
  );
};

export default PaymentProcessingView;
