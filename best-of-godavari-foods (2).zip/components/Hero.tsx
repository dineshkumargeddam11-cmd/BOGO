
import React, { useEffect, useRef } from 'react';

const Hero: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Ensure video plays automatically
    if (videoRef.current) {
      videoRef.current.play().catch(error => {
        console.error("Video autoplay failed:", error);
      });
    }
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative w-full h-[80vh] min-h-[600px] overflow-hidden mb-12 bg-gray-900">
      {/* Video Background */}
      <video
        ref={videoRef}
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover opacity-50"
        poster="https://images.unsplash.com/photo-1596040033229-a9821ebd058d?q=80&w=2070&auto=format&fit=crop"
      >
        {/* Authentic Spices Video */}
        <source src="https://videos.pexels.com/video-files/2827237/2827237-hd_1920_1080_30fps.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Dark Overlay Gradient to ensure text is readable over the video */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-black/70"></div>

      {/* Hero Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4 py-20">
        <span className="text-saffron-300 font-bold tracking-widest uppercase text-sm md:text-base mb-4 animate-fade-in-up shadow-sm bg-black/20 px-4 py-1 rounded-full backdrop-blur-sm border border-saffron-500/30">
          From the Banks of Godavari
        </span>
        <h2 className="text-5xl md:text-7xl font-extrabold text-white tracking-tight leading-none drop-shadow-2xl mb-6">
          Purity of <span className="text-transparent bg-clip-text bg-gradient-to-r from-saffron-400 to-brand-500">Tradition</span>
        </h2>
        <p className="max-w-2xl text-lg md:text-xl text-gray-100 font-light leading-relaxed drop-shadow-lg mb-10">
          Authentic handcrafted sweets, spicy pickles, and aromatic staples made with generations of love and the finest ingredients.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 w-full justify-center">
          <button 
            onClick={() => scrollToSection('products')}
            className="px-10 py-4 bg-saffron-600 hover:bg-saffron-700 text-white font-bold text-lg rounded-full transition-all transform hover:scale-105 shadow-lg border-2 border-transparent"
          >
            Shop Now
          </button>
          <button 
             onClick={() => scrollToSection('story')}
             className="px-10 py-4 bg-white/10 hover:bg-white/20 text-white font-bold text-lg rounded-full transition-all border-2 border-white/50 hover:border-white backdrop-blur-sm"
          >
            Our Story
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
