
import React, { useState } from 'react';
import { ProductCategory } from '../types';

interface HeaderProps {
  activeCategory: ProductCategory | 'ALL';
  setActiveCategory: (category: ProductCategory | 'ALL') => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
}

const NavLink: React.FC<{
  label: string;
  category: ProductCategory | 'ALL';
  activeCategory: ProductCategory | 'ALL';
  onClick: (category: ProductCategory | 'ALL') => void;
  isMobile?: boolean;
}> = ({ label, category, activeCategory, onClick, isMobile = false }) => (
  <button
    onClick={() => onClick(category)}
    className={`w-full text-left px-3 py-2 text-sm md:text-base font-medium rounded-md transition-colors duration-200 relative ${
      activeCategory === category
        ? 'text-brand-700'
        : 'text-gray-600 hover:text-brand-700'
    } ${isMobile ? 'text-lg' : ''}`}
  >
    {label}
     {activeCategory === category && !isMobile && (
        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1/2 h-0.5 bg-brand-700 rounded-full" />
    )}
  </button>
);

const SearchBar: React.FC<{searchTerm: string; setSearchTerm: (term: string) => void; className?: string}> = ({searchTerm, setSearchTerm, className=""}) => {
  return (
    <div className={`relative w-full ${className}`}>
        <input 
          type="text"
          placeholder="Search for sweets, pickles..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-brand-200 focus:border-brand-500 transition-colors bg-stone-50"
        />
        <svg className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
    </div>
  );
};


const Header: React.FC<HeaderProps> = ({ activeCategory, setActiveCategory, searchTerm, setSearchTerm }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleNavClick = (category: ProductCategory | 'ALL') => {
    setActiveCategory(category);
    setIsMobileMenuOpen(false);
  }

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md shadow-sm z-50 border-b border-stone-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          <div className="flex-shrink-0 flex flex-col justify-center">
            <h1 className="text-2xl md:text-3xl font-extrabold text-brand-800 leading-none font-sans tracking-tight">
              Best of <span className="text-saffron-600">Godavari</span>
            </h1>
            <p className="text-[10px] md:text-xs text-gray-500 font-medium tracking-wider mt-1 uppercase">Tradition is Our Method</p>
          </div>

          <div className="hidden md:flex flex-1 items-center justify-center px-8 lg:px-16">
             <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} className="max-w-lg" />
          </div>
          
          <nav className="hidden md:flex items-center space-x-2">
            <NavLink label="Home" category="ALL" activeCategory={activeCategory} onClick={handleNavClick} />
            <NavLink label="Sweets" category={ProductCategory.SWEETS} activeCategory={activeCategory} onClick={handleNavClick} />
            <NavLink label="Pickles" category={ProductCategory.PICKLES} activeCategory={activeCategory} onClick={handleNavClick} />
            <NavLink label="Snacks" category={ProductCategory.SNACKS} activeCategory={activeCategory} onClick={handleNavClick} />
            <NavLink label="Staples" category={ProductCategory.STAPLES} activeCategory={activeCategory} onClick={handleNavClick} />
          </nav>

          <div className="md:hidden">
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-gray-600 hover:text-brand-700">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"} />
              </svg>
            </button>
          </div>
        </div>
        
        <div className="md:hidden pb-4">
            <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-stone-200 absolute top-full left-0 w-full shadow-lg">
          <div className="px-4 pt-2 pb-4 space-y-2">
            <NavLink label="Home" category="ALL" activeCategory={activeCategory} onClick={handleNavClick} isMobile />
            <NavLink label="Sweets" category={ProductCategory.SWEETS} activeCategory={activeCategory} onClick={handleNavClick} isMobile />
            <NavLink label="Pickles" category={ProductCategory.PICKLES} activeCategory={activeCategory} onClick={handleNavClick} isMobile />
            <NavLink label="Snacks" category={ProductCategory.SNACKS} activeCategory={activeCategory} onClick={handleNavClick} isMobile />
            <NavLink label="Staples" category={ProductCategory.STAPLES} activeCategory={activeCategory} onClick={handleNavClick} isMobile />
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
