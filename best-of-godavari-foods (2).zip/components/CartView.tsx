
import React from 'react';
import { useCart } from '../context/CartContext';
import { PRODUCTS } from '../constants';
import { Product } from '../types';

interface CartViewProps {
  onClose: () => void;
  onCheckout: () => void;
}

const CartView: React.FC<CartViewProps> = ({ onClose, onCheckout }) => {
  const { cartItems, updateQuantity, removeFromCart, subtotal } = useCart();

  const getProductDetails = (productId: number) => {
    return PRODUCTS.find(p => p.id === productId);
  };

  const getVariantPrice = (product: Product, variantWeight: string) => {
    return product.variants.find(v => v.weight === variantWeight)?.price || 0;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-end">
      <div className="w-full max-w-md bg-white h-full flex flex-col">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-2xl font-bold text-deepgreen-800">Your Bag</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {cartItems.length === 0 ? (
          <div className="flex-grow flex items-center justify-center">
            <p className="text-gray-500">Your bag is empty.</p>
          </div>
        ) : (
          <div className="flex-grow overflow-y-auto p-4 space-y-4">
            {cartItems.map(item => {
              const product = getProductDetails(item.productId);
              if (!product) return null;
              const price = getVariantPrice(product, item.variantWeight);
              return (
                <div key={`${item.productId}-${item.variantWeight}`} className="flex items-start space-x-4">
                  <img src={product.image} alt={product.name} className="w-20 h-20 rounded-md object-cover"/>
                  <div className="flex-grow">
                    <h4 className="font-semibold">{product.name} <span className="font-normal text-gray-600">({product.teluguName})</span></h4>
                    <p className="text-sm text-gray-500">{item.variantWeight}</p>
                    <p className="text-sm font-bold text-deepgreen-700">₹{price}</p>
                    <div className="flex items-center mt-2 border border-gray-200 rounded-md w-min">
                        <button 
                            onClick={() => updateQuantity(item.productId, item.variantWeight, item.quantity - 1)} 
                            className="px-3 py-1 text-lg font-semibold text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-l-md"
                            aria-label="Decrease quantity"
                        >
                            -
                        </button>
                        <span className="px-4 py-1 text-base font-bold text-gray-800 bg-white border-x border-gray-200" aria-live="polite">
                            {item.quantity}
                        </span>
                        <button 
                            onClick={() => updateQuantity(item.productId, item.variantWeight, item.quantity + 1)} 
                            className="px-3 py-1 text-lg font-semibold text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-r-md"
                            aria-label="Increase quantity"
                        >
                            +
                        </button>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">₹{price * item.quantity}</p>
                    <button onClick={() => removeFromCart(item.productId, item.variantWeight)} className="text-xs text-red-500 hover:underline mt-1">Remove</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {cartItems.length > 0 && (
          <div className="p-4 border-t space-y-2">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>₹{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-gray-500">
              <span>Shipping Fee</span>
              <span className="font-semibold text-gray-700">As per actuals</span>
            </div>
            <div className="flex justify-between font-bold text-lg text-gray-800">
              <span>Grand Total</span>
              <span>₹{subtotal.toFixed(2)} + Shipping</span>
            </div>
            <button
              onClick={onCheckout}
              className="w-full bg-saffron-600 text-white font-bold py-3 rounded-lg mt-4 hover:bg-saffron-700 transition-colors"
            >
              Proceed to Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartView;