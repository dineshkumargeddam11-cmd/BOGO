
import React, { useState } from 'react';
import { Product, ProductVariant } from '../types';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';

interface ProductCardProps {
  product: Product;
}

const StarRating: React.FC<{ rating: number; reviewCount: number }> = ({ rating, reviewCount }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

  return (
    <div className="flex items-center">
      {[...Array(fullStars)].map((_, i) => (
        <svg key={`full-${i}`} className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
      ))}
      {halfStar && <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0v15z"/></svg>}
      {[...Array(emptyStars)].map((_, i) => (
        <svg key={`empty-${i}`} className="w-4 h-4 text-gray-300" fill="currentColor" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
      ))}
      <span className="text-xs text-gray-500 ml-2">({reviewCount})</span>
    </div>
  );
};


const QuantityCounter: React.FC<{
  productId: number;
  variantWeight: string;
}> = ({ productId, variantWeight }) => {
  const { getItemQuantity, updateQuantity } = useCart();
  const quantity = getItemQuantity(productId, variantWeight);

  return (
    <div className="flex items-center justify-center w-full bg-saffron-600 text-white rounded-lg h-full">
      <button
        onClick={() => updateQuantity(productId, variantWeight, quantity - 1)}
        className="px-4 py-2 text-lg font-bold hover:bg-saffron-700 rounded-l-lg"
        aria-label="Decrease quantity"
      >
        -
      </button>
      <span className="px-4 py-2 text-lg font-semibold" aria-live="polite">{quantity}</span>
      <button
        onClick={() => updateQuantity(productId, variantWeight, quantity + 1)}
        className="px-4 py-2 text-lg font-bold hover:bg-saffron-700 rounded-r-lg"
        aria-label="Increase quantity"
      >
        +
      </button>
    </div>
  );
};

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant>(product.variants[0]);
  const { addToCart, getItemQuantity } = useCart();
  const { addToast } = useToast();

  const quantity = getItemQuantity(product.id, selectedVariant.weight);
  
  const handleAddToCart = () => {
    addToCart(product.id, selectedVariant.weight);
    addToast(`${product.name} (${product.teluguName}) - ${selectedVariant.weight} added to bag`, 'success');
  }

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col transition-transform duration-300 hover:scale-105">
      <div className="aspect-square w-full overflow-hidden">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold text-gray-800">{product.name} <span className="font-normal text-gray-600">({product.teluguName})</span></h3>
        <div className="my-1">
          <StarRating rating={product.rating} reviewCount={product.reviewCount} />
        </div>
        <p className="text-sm text-gray-500 mt-1 flex-grow">{product.description}</p>
        
        <div className="mt-4">
          <span className="text-xs font-medium text-gray-600">Weight</span>
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            {product.variants.map(variant => (
              <button
                key={variant.weight}
                onClick={() => setSelectedVariant(variant)}
                className={`px-3 py-1 text-sm font-semibold border rounded-md transition-colors duration-200 ${
                  selectedVariant.weight === variant.weight
                    ? 'bg-saffron-600 text-white border-saffron-600'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-saffron-500 hover:text-saffron-600'
                }`}
              >
                {variant.weight}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between mt-4">
          <span className="text-xl font-bold text-deepgreen-800">₹{selectedVariant.price}</span>
        </div>

        <div className="mt-4 h-10">
          {quantity > 0 ? (
            <QuantityCounter productId={product.id} variantWeight={selectedVariant.weight} />
          ) : (
            <button
              onClick={handleAddToCart}
              className="w-full bg-deepgreen-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-deepgreen-800 transition-colors duration-300 h-full"
            >
              Add to Bag
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
