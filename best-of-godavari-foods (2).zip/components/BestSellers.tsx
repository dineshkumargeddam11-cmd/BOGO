
import React from 'react';
import { Product } from '../types';

interface BestSellersProps {
  products: Product[];
}

const StarRating: React.FC<{ rating: number }> = ({ rating }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

  return (
    <div className="flex items-center">
      {[...Array(fullStars)].map((_, i) => (
        <svg key={`full-${i}`} className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
      ))}
      {halfStar && <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0v15z"/></svg>}
      {[...Array(emptyStars)].map((_, i) => (
        <svg key={`empty-${i}`} className="w-4 h-4 text-gray-300" fill="currentColor" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/></svg>
      ))}
    </div>
  );
};

const BestSellerCard: React.FC<{ product: Product }> = ({ product }) => (
    <div className="flex-shrink-0 w-64 bg-white rounded-lg shadow-md overflow-hidden snap-start transition-transform duration-300 hover:scale-105">
        <img src={product.image} alt={product.name} className="w-full h-40 object-cover" />
        <div className="p-4">
            <h4 className="font-semibold text-gray-800 truncate">{product.name}</h4>
            <div className="mt-1">
                <StarRating rating={product.rating} />
            </div>
            <p className="text-sm text-deepgreen-700 font-bold mt-2">From ₹{product.variants[0].price}</p>
        </div>
    </div>
);

const BestSellers: React.FC<BestSellersProps> = ({ products }) => {
  return (
    <section className="py-12 bg-saffron-100/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-brand-700 mb-8">Our Best Sellers</h2>
        <div className="flex space-x-6 overflow-x-auto pb-4 scrollbar-thin scrollbar-thumb-saffron-400 scrollbar-track-saffron-100 snap-x snap-mandatory">
          {products.map(product => (
            <BestSellerCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestSellers;
