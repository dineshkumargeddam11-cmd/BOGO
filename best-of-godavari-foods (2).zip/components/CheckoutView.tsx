
import React, { useState, useMemo } from 'react';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';
import { DOMESTIC_CITIES, INTERNATIONAL_COUNTRIES, PRODUCTS } from '../constants';

interface CheckoutViewProps {
  onClose: () => void;
  onOrderRequestSent: () => void;
  onPlaceOrder: () => void;
}

const DOMESTIC_MIN_WEIGHT = 5;
const INTERNATIONAL_MIN_WEIGHT = 10;

const parseWeight = (weightStr: string): number => {
  const [value, unit] = weightStr.split(' ');
  const numValue = parseFloat(value);
  if (unit.toLowerCase() === 'kg') {
    return numValue;
  }
  if (unit.toLowerCase() === 'gms') {
    return numValue / 1000;
  }
  return 0;
};

const CheckoutView: React.FC<CheckoutViewProps> = ({ onClose, onOrderRequestSent, onPlaceOrder }) => {
  const [shippingType, setShippingType] = useState<'domestic' | 'international'>('domestic');
  const { cartItems, subtotal, clearCart } = useCart();
  const { addToast } = useToast();

  const totalWeight = useMemo(() => {
    return cartItems.reduce((total, item) => {
      const weight = parseWeight(item.variantWeight);
      return total + weight * item.quantity;
    }, 0);
  }, [cartItems]);

  const { isOrderValid, minWeight } = useMemo(() => {
    if (shippingType === 'domestic') {
      return { isOrderValid: totalWeight >= DOMESTIC_MIN_WEIGHT, minWeight: DOMESTIC_MIN_WEIGHT };
    }
    // international
    return { isOrderValid: totalWeight >= INTERNATIONAL_MIN_WEIGHT, minWeight: INTERNATIONAL_MIN_WEIGHT };
  }, [totalWeight, shippingType]);

  const handleOrderRequest = () => {
    const header = "Hello Best of Godavari, I would like to place an order with the following details:\n\n";

    const itemsText = cartItems.map(item => {
        const product = PRODUCTS.find(p => p.id === item.productId);
        if (!product) return '';
        return `- ${product.name} (${item.variantWeight}) x ${item.quantity}`;
    }).join('\n');

    const footer = `\n\n*Total Weight:* ${totalWeight.toFixed(2)} kg\n*Subtotal:* ₹${subtotal.toFixed(2)}\n*Shipping Fee:* To be calculated based on actuals.\n\n*Shipping Type:* ${shippingType}\n\nPlease contact me to confirm this order. Thank you!`;

    const message = header + itemsText + footer;
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/918317628215?text=${encodedMessage}`;

    window.open(whatsappUrl, '_blank');

    addToast('Thank you! We will contact you soon.', 'success');
    clearCart();
    onOrderRequestSent();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-2xl font-bold text-deepgreen-800">Shipping Details</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
             </svg>
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-6">
          <fieldset>
            <legend className="text-lg font-semibold text-gray-800 mb-2">1. Shipping Option</legend>
            <div className="flex flex-col sm:flex-row gap-4">
              <label className="flex flex-1 items-center p-3 border rounded-lg has-[:checked]:bg-saffron-50 has-[:checked]:border-saffron-500 has-[:checked]:text-gray-800 cursor-pointer">
                <input type="radio" name="shippingType" value="domestic" checked={shippingType === 'domestic'} onChange={() => setShippingType('domestic')} className="form-radio text-saffron-600"/>
                <span className="ml-2">Domestic (Tier 1 South India)</span>
              </label>
              <label className="flex flex-1 items-center p-3 border rounded-lg has-[:checked]:bg-saffron-50 has-[:checked]:border-saffron-500 has-[:checked]:text-gray-800 cursor-pointer">
                <input type="radio" name="shippingType" value="international" checked={shippingType === 'international'} onChange={() => setShippingType('international')} className="form-radio text-saffron-600"/>
                <span className="ml-2">International Shipping</span>
              </label>
            </div>
             <div className="mt-3 p-2 bg-blue-50 text-blue-800 rounded-lg text-sm flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
              </svg>
              {shippingType === 'domestic' ? (
                <span>Note: 2-3 days estimated delivery.</span>
              ) : (
                <span>Note: Estimated delivery is 4-7 days.</span>
              )}
            </div>
          </fieldset>
          
          <div className={`p-4 rounded-lg text-center transition-all duration-300 ${isOrderValid ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              <p className="font-semibold">Minimum package weight for {shippingType} shipping is {minWeight} kg.</p>
              <p>Your current order weight: <span className="font-bold">{totalWeight.toFixed(2)} kg</span></p>
          </div>

          <fieldset disabled={!isOrderValid} className="space-y-6 disabled:opacity-50 disabled:cursor-not-allowed">
            <div className="bg-saffron-50 border-2 border-saffron-500 rounded-lg p-4 ring-4 ring-saffron-100">
              <label htmlFor="destination" className="block text-lg font-bold text-gray-800 mb-2">2. Destination <span className="font-medium text-gray-600">(Choose your city)</span></label>
              <select id="destination" className="mt-1 block w-full pl-3 pr-10 py-3 text-base border-gray-300 focus:outline-none focus:ring-saffron-600 focus:border-saffron-600 sm:text-sm rounded-md shadow-sm">
                {shippingType === 'domestic' ? (
                  DOMESTIC_CITIES.map(city => <option key={city}>{city}</option>)
                ) : (
                  INTERNATIONAL_COUNTRIES.map(country => <option key={country}>{country}</option>)
                )}
              </select>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2"><h3 className="text-lg font-semibold text-gray-800">3. Delivery Details</h3></div>
              <div><label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label><input type="text" id="name" className="mt-1 block w-full p-2 border border-gray-300 rounded-md"/></div>
              <div><label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone</label><input type="tel" id="phone" className="mt-1 block w-full p-2 border border-gray-300 rounded-md"/></div>
              <div className="md:col-span-2"><label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label><input type="text" id="address" className="mt-1 block w-full p-2 border border-gray-300 rounded-md"/></div>
            </div>
            
          </fieldset>

        </div>
        <div className="p-4 border-t bg-gray-50 flex flex-col sm:flex-row gap-4">
          <button
            onClick={handleOrderRequest}
            disabled={!isOrderValid}
            className="flex-1 bg-green-600 text-white font-bold py-3 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed border border-transparent"
          >
            Send Request for Placing Order
          </button>
          <button
            onClick={onPlaceOrder}
            disabled={!isOrderValid}
            className="flex-1 bg-saffron-600 text-white font-bold py-3 rounded-lg hover:bg-saffron-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed border border-transparent"
          >
            Place Order (Pay Now)
          </button>
        </div>
      </div>
    </div>
  );
};

export default CheckoutView;
