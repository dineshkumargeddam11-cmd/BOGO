
import React from 'react';
import { CartItem } from '../types';
import { PRODUCTS } from '../constants';

interface OrderConfirmationViewProps {
  orderDetails: {
    items: CartItem[];
    total: number;
  };
  onClose: () => void;
}

const OrderConfirmationView: React.FC<OrderConfirmationViewProps> = ({ orderDetails, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
        <div className="p-6 text-center border-b border-gray-200">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
          </div>
          <h2 className="text-2xl font-bold text-deepgreen-800 mt-4">Thank You For Your Order!</h2>
          <p className="text-gray-600 mt-1">Your order has been placed successfully.</p>
        </div>

        <div className="p-6 overflow-y-auto">
          <h3 className="font-semibold text-gray-800 mb-4">Order Summary</h3>
          <div className="space-y-3">
            {orderDetails.items.map(item => {
              const product = PRODUCTS.find(p => p.id === item.productId);
              if (!product) return null;
              const variant = product.variants.find(v => v.weight === item.variantWeight);
              return (
                <div key={`${item.productId}-${item.variantWeight}`} className="flex justify-between items-center text-sm">
                  <div>
                    <p className="font-semibold text-gray-700">{product.name} ({item.variantWeight})</p>
                    <p className="text-gray-500">Qty: {item.quantity}</p>
                  </div>
                  <p className="font-semibold text-gray-800">₹{((variant?.price || 0) * item.quantity).toFixed(2)}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-6 pt-4 border-t border-dashed">
            <div className="flex justify-between font-bold text-lg">
              <span>Total Paid</span>
              <span>₹{orderDetails.total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="p-6 border-t bg-gray-50">
          <button
            onClick={onClose}
            className="w-full bg-saffron-600 text-white font-bold py-3 rounded-lg hover:bg-saffron-700 transition-colors"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmationView;
