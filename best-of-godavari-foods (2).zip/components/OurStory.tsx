
import React from 'react';

const OurStory: React.FC = () => {
  return (
    <section className="bg-white py-16 sm:py-24 overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
            <span className="text-saffron-600 font-bold tracking-wider uppercase text-sm mb-2 block font-sans">Roots & Heritage</span>
            <h2 className="text-4xl md:text-5xl font-bold text-brand-800 mb-6 font-serif leading-tight">
              The Taste of <br/>Godavari
            </h2>
            <div className="w-20 h-1 bg-saffron-500 mb-8"></div>
            <p className="text-gray-700 mb-6 leading-relaxed text-lg font-light">
              Living far from home, the heart often craves the simple, authentic flavors of the Godavari region—the spicy Avakaya made by grandmother, the melt-in-mouth Pootharekulu, or the crunch of fresh Chegodilu.
            </p>
            <p className="text-gray-700 mb-6 leading-relaxed text-lg font-light">
              <strong className="text-brand-800 font-medium">Best of Godavari</strong> was born from this nostalgia. We bridge the distance between you and your roots, delivering handcrafted delicacies made in traditional kitchens, free from preservatives and full of love.
            </p>
             <p className="text-gray-700 leading-relaxed text-lg font-light italic">
              "From the banks of the Godavari to your doorstep, we deliver not just food, but a piece of home."
            </p>
          </div>
          <div className="order-1 md:order-2 relative">
            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-saffron-100 rounded-full -z-10"></div>
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-brand-100 rounded-full -z-10"></div>
            
            {/* Godavari Bridge Image */}
            <div className="relative rounded-xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
                 <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Godavari_Arch_Bridge.jpg/1280px-Godavari_Arch_Bridge.jpg" 
                  alt="Godavari Arch Bridge at Rajahmundry" 
                  className="w-full h-full object-cover min-h-[400px] sepia-[.25]"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                    <p className="text-white font-serif text-xl">The Iconic Arch Bridge</p>
                    <p className="text-saffron-300 text-sm">Rajahmundry, Andhra Pradesh</p>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OurStory;
