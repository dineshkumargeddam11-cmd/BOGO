
import React, { createContext, useContext, useState, ReactNode, useMemo } from 'react';
import { CartItem, Product } from '../types';
import { PRODUCTS } from '../constants';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (productId: number, variantWeight: string) => void;
  updateQuantity: (productId: number, variantWeight: string, quantity: number) => void;
  removeFromCart: (productId: number, variantWeight: string) => void;
  getItemQuantity: (productId: number, variantWeight: string) => number;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

interface CartProviderProps {
  children: ReactNode;
}

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const addToCart = (productId: number, variantWeight: string) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(
        item => item.productId === productId && item.variantWeight === variantWeight
      );
      if (existingItem) {
        return prevItems.map(item =>
          item.productId === productId && item.variantWeight === variantWeight
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevItems, { productId, variantWeight, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: number, variantWeight: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId, variantWeight);
    } else {
      setCartItems(prevItems =>
        prevItems.map(item =>
          item.productId === productId && item.variantWeight === variantWeight
            ? { ...item, quantity }
            : item
        )
      );
    }
  };

  const removeFromCart = (productId: number, variantWeight: string) => {
    setCartItems(prevItems =>
      prevItems.filter(
        item => !(item.productId === productId && item.variantWeight === variantWeight)
      )
    );
  };

  const getItemQuantity = (productId: number, variantWeight: string) => {
    const item = cartItems.find(
      i => i.productId === productId && i.variantWeight === variantWeight
    );
    return item ? item.quantity : 0;
  };
  
  const clearCart = () => setCartItems([]);

  const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);

  const subtotal = useMemo(() => cartItems.reduce((total, item) => {
    const product = PRODUCTS.find(p => p.id === item.productId);
    if (!product) return total;
    const variant = product.variants.find(v => v.weight === item.variantWeight);
    const price = variant?.price || 0;
    return total + price * item.quantity;
  }, 0), [cartItems]);

  const value = {
    cartItems,
    addToCart,
    updateQuantity,
    removeFromCart,
    getItemQuantity,
    clearCart,
    totalItems,
    subtotal,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
